# Visit 2.9.2 log file
ScriptVersion = "2.9.2"
if ScriptVersion != Version():
    print "This script is for VisIt %s. It may not work with version %s" % (ScriptVersion, Version())
ShowAllWindows()
OpenDatabase("localhost:/home/nfs/wol023/esl/myexamples/5D_drift/mikhail_universal_5D_perun_kz_1kz_Lz10_weno5_detail/plt_potential_plots/plt.potential*.3d.hdf5 database", 0)
metadata = GetMetaData("localhost:/home/nfs/wol023/esl/myexamples/5D_drift/mikhail_universal_5D_perun_kz_1kz_Lz10_weno5_detail/plt_potential_plots/plt.potential*.3d.hdf5 database", -1)
AddPlot("Mesh", "Mesh", 1, 0)
MeshAtts = MeshAttributes()
MeshAtts.legendFlag = 0
MeshAtts.lineStyle = MeshAtts.SOLID  # SOLID, DASH, DOT, DOTDASH
MeshAtts.lineWidth = 0
MeshAtts.meshColor = (0, 0, 0, 255)
MeshAtts.outlineOnlyFlag = 0
MeshAtts.errorTolerance = 0.01
MeshAtts.meshColorSource = MeshAtts.Foreground  # Foreground, MeshCustom
MeshAtts.opaqueColorSource = MeshAtts.Background  # Background, OpaqueCustom
MeshAtts.opaqueMode = MeshAtts.Auto  # Auto, On, Off
MeshAtts.pointSize = 0.05
MeshAtts.opaqueColor = (255, 255, 255, 255)
MeshAtts.smoothingLevel = MeshAtts.None  # None, Fast, High
MeshAtts.pointSizeVarEnabled = 0
MeshAtts.pointSizeVar = "default"
MeshAtts.pointType = MeshAtts.Point  # Box, Axis, Icosahedron, Octahedron, Tetrahedron, SphereGeometry, Point, Sphere
MeshAtts.showInternal = 0
MeshAtts.pointSizePixels = 2
MeshAtts.opacity = 1
SetPlotOptions(MeshAtts)
HideActivePlots()
AddOperator("ThreeSlice", 0)
ThreeSliceAtts = ThreeSliceAttributes()
ThreeSliceAtts.x = 3.14159
ThreeSliceAtts.y = 8.37758
ThreeSliceAtts.z = 4.18879
ThreeSliceAtts.interactive = 1
SetOperatorOptions(ThreeSliceAtts, 0)
AddPlot("Pseudocolor", "component_0", 1, 0)
AddOperator("ThreeSlice", 0)
ThreeSliceAtts = ThreeSliceAttributes()
ThreeSliceAtts.x = 3.14159
ThreeSliceAtts.y = 8.37758
ThreeSliceAtts.z = 4.18879
ThreeSliceAtts.interactive = 1
SetOperatorOptions(ThreeSliceAtts, 0)
DrawPlots()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
SetTimeSliderState(0)
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
DeleteActivePlots()
DeleteActivePlots()
OpenDatabase("localhost:/home/nfs/wol023/esl/myexamples/5D_drift/mikhail_universal_5D_perun_kz_1kz_Lz10_weno5_detail/plt_potential_plots/plt.potential*.3d.hdf5 database")
OpenDatabase("localhost:/home/nfs/wol023/esl/myexamples/5D_drift/mikhail_universal_5D_perun_kz_1kz_Lz1_6_weno5/plt_potential_plots/plt.potential*.3d.hdf5 database", 0)
metadata = GetMetaData("localhost:/home/nfs/wol023/esl/myexamples/5D_drift/mikhail_universal_5D_perun_kz_1kz_Lz1_6_weno5/plt_potential_plots/plt.potential*.3d.hdf5 database", -1)
AddPlot("Mesh", "Mesh", 1, 0)
MeshAtts = MeshAttributes()
MeshAtts.legendFlag = 0
MeshAtts.lineStyle = MeshAtts.SOLID  # SOLID, DASH, DOT, DOTDASH
MeshAtts.lineWidth = 0
MeshAtts.meshColor = (0, 0, 0, 255)
MeshAtts.outlineOnlyFlag = 0
MeshAtts.errorTolerance = 0.01
MeshAtts.meshColorSource = MeshAtts.Foreground  # Foreground, MeshCustom
MeshAtts.opaqueColorSource = MeshAtts.Background  # Background, OpaqueCustom
MeshAtts.opaqueMode = MeshAtts.Auto  # Auto, On, Off
MeshAtts.pointSize = 0.05
MeshAtts.opaqueColor = (255, 255, 255, 255)
MeshAtts.smoothingLevel = MeshAtts.None  # None, Fast, High
MeshAtts.pointSizeVarEnabled = 0
MeshAtts.pointSizeVar = "default"
MeshAtts.pointType = MeshAtts.Point  # Box, Axis, Icosahedron, Octahedron, Tetrahedron, SphereGeometry, Point, Sphere
MeshAtts.showInternal = 0
MeshAtts.pointSizePixels = 2
MeshAtts.opacity = 1
SetPlotOptions(MeshAtts)
HideActivePlots()
AddOperator("ThreeSlice", 0)
ThreeSliceAtts = ThreeSliceAttributes()
ThreeSliceAtts.x = 3.14159
ThreeSliceAtts.y = 8.37758
ThreeSliceAtts.z = 4.18879
ThreeSliceAtts.interactive = 1
SetOperatorOptions(ThreeSliceAtts, 0)
AddPlot("Pseudocolor", "component_0", 1, 0)
AddOperator("ThreeSlice", 0)
ThreeSliceAtts = ThreeSliceAttributes()
ThreeSliceAtts.x = 3.14159
ThreeSliceAtts.y = 8.37758
ThreeSliceAtts.z = 4.18879
ThreeSliceAtts.interactive = 1
SetOperatorOptions(ThreeSliceAtts, 0)
DrawPlots()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderPreviousState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
TimeSliderNextState()
